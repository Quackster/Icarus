package org.alexdev.icarus.messages.outgoing.room.items;

import java.util.List;

import org.alexdev.icarus.game.item.Item;
import org.alexdev.icarus.game.util.ItemUtil;
import org.alexdev.icarus.messages.headers.Outgoing;
import org.alexdev.icarus.messages.types.MessageComposer;
import org.alexdev.icarus.util.Util;

public class FloorItemsMessageComposer extends MessageComposer {

    private List<Item> items;

    public FloorItemsMessageComposer(List<Item> list) {
        this.items = list;
    }

    @Override
    public void compose() {
        this.response.init(Outgoing.FloorItemsMessageComposer);
        this.response.writeInt(this.items.size());
        for (Item floorItem : this.items) { 
            this.response.writeInt(floorItem.getOwnerId());
            this.response.writeString(floorItem.getOwnerName());
        }

        this.response.writeInt(this.items.size());
        for (Item floorItem : this.items) {
            this.response.writeInt(floorItem.getId());
            this.response.writeInt(floorItem.getDefinition().getSpriteId());
            this.response.writeInt(floorItem.getPosition().getX());
            this.response.writeInt(floorItem.getPosition().getY());
            this.response.writeInt(floorItem.getPosition().getRotation());
            this.response.writeString("" + Util.format(floorItem.getPosition().getZ()));
            this.response.writeString("");
            ItemUtil.generateExtraData(floorItem, this.response);
            this.response.writeInt(-1);
            this.response.writeInt(floorItem.getDefinition().getInteractionModes() > 0 ? 1 : 0);
            this.response.writeInt(floorItem.getOwnerId());
        }
    }
}
