package org.alexdev.icarus.messages.outgoing.user;

import java.util.Map;
import java.util.Map.Entry;

import org.alexdev.icarus.messages.headers.Outgoing;
import org.alexdev.icarus.messages.types.MessageComposer;

public class ActivityPointsComposer extends MessageComposer {

    private Map<Integer, Integer> currencies;
    
    public ActivityPointsComposer(Map<Integer, Integer> currencies) {
        this.currencies = currencies;
    }

    @Override
    public void compose() {
        
        this.response.init(Outgoing.ActivityPointsComposer);
        this.response.writeInt(this.currencies.size());
        
        for (Entry<Integer, Integer> set : this.currencies.entrySet()) {
            this.response.writeInt(set.getKey());
            this.response.writeInt(set.getValue());
        }
    }
}
