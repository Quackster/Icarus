package org.alexdev.icarus.messages.outgoing.room.items;

import java.util.List;

import org.alexdev.icarus.game.item.Item;
import org.alexdev.icarus.game.util.ItemUtil;
import org.alexdev.icarus.messages.headers.Outgoing;
import org.alexdev.icarus.messages.types.MessageComposer;

public class WallItemsMessageComposer extends MessageComposer {

    private List<Item> items;

    public WallItemsMessageComposer(List<Item> list) {
        this.items = list;
    }

    @Override
    public void compose() {
        
        this.response.init(Outgoing.WallItemsMessageComposer);
        
        this.response.writeInt(this.items.size());
        for (Item wallItem : this.items) { 
            this.response.writeInt(wallItem.getOwnerId());
            this.response.writeString(wallItem.getOwnerName());
        }

        this.response.writeInt(this.items.size());
        
        for (Item wallItem : this.items) {
            this.response.writeString(wallItem.getId() + "");
            this.response.writeInt(wallItem.getDefinition().getSpriteId());
            this.response.writeString(wallItem.getWallPosition());
            ItemUtil.generateWallExtraData(wallItem, response);
            this.response.writeInt(-1);
            this.response.writeInt(wallItem.getDefinition().getInteractionModes() > 0 ? 1 : 0);
            this.response.writeInt(wallItem.getOwnerId());
        }
    }
}
