package org.alexdev.icarus.messages.outgoing.navigator;

import org.alexdev.icarus.messages.headers.Outgoing;
import org.alexdev.icarus.messages.types.MessageComposer;

public class NavigatorPromoteCategoriesComposer extends MessageComposer {

    @Override
    public void compose() {
        this.response.init(Outgoing.NavigatorPromoteCategoriesComposer);
        this.response.writeInt(1);
        this.response.writeInt(1);
        this.response.writeString("Promoted Rooms");
        this.response.writeBool(true);
    }
}
