package org.alexdev.icarus.messages.outgoing.room.notify;

import org.alexdev.icarus.messages.headers.Outgoing;
import org.alexdev.icarus.messages.types.MessageComposer;

public class RoomEnterErrorMessageComposer extends MessageComposer {
    
    private int errorCode;

    public RoomEnterErrorMessageComposer(int errorCode) {
        this.errorCode = errorCode;
    }

    @Override
    public void compose() {
        this.response.init(Outgoing.RoomEnterErrorMessageComposer);
        this.response.writeInt(this.errorCode);

    }
}
