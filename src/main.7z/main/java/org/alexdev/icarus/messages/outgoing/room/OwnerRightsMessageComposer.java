package org.alexdev.icarus.messages.outgoing.room;

import org.alexdev.icarus.messages.headers.Outgoing;
import org.alexdev.icarus.messages.types.MessageComposer;

public class OwnerRightsMessageComposer extends MessageComposer {

    @Override
    public void compose() {
        this.response.init(Outgoing.OwnerRightsMessageComposer);
    }
}
