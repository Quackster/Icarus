package org.alexdev.icarus.messages.outgoing.messenger;

import java.util.List;

import org.alexdev.icarus.game.messenger.MessengerUser;
import org.alexdev.icarus.game.player.Player;
import org.alexdev.icarus.messages.headers.Outgoing;
import org.alexdev.icarus.messages.types.MessageComposer;

public class MessengerRequestsMessageComposer extends MessageComposer {

    private Player player;
    private List<MessengerUser> requests;

    public MessengerRequestsMessageComposer(Player player, List<MessengerUser> requests) {
        this.player = player;
        this.requests = requests;
    }

    @Override
    public void compose() {
        this.response.init(Outgoing.MessengerRequestsMessageComposer);
        this.response.writeInt(this.player.getEntityId());
        this.response.writeInt(this.requests.size()); 

        for (MessengerUser user : this.requests) {
            this.response.writeInt(user.getUserId());
            this.response.writeString(user.getDetails().getName());
            this.response.writeString(user.getDetails().getFigure());
        }
    }
}
