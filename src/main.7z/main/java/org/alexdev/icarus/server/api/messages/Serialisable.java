package org.alexdev.icarus.server.api.messages;

public interface Serialisable {
    public void compose(Response response);
}
