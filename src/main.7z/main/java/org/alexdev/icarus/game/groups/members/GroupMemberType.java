package org.alexdev.icarus.game.groups.members;

public enum GroupMemberType {
    ADMINISTRATOR,
    MEMBER,
    REQUEST
}
