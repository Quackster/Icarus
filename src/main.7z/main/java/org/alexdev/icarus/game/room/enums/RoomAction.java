package org.alexdev.icarus.game.room.enums;

public enum RoomAction {
    LEAVE_ROOM,
    FORWARD_ROOM
}
