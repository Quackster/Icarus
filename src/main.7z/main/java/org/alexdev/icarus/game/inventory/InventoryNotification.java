package org.alexdev.icarus.game.inventory;

public enum InventoryNotification {
    ALERT,
    NONE
}
