package org.alexdev.icarus.game.room.scheduler;

public enum TaskType {
    REPEAT,
    RUN_ONCE
}
