package org.alexdev.icarus.game.plugins;

public class PluginException extends Throwable {
    
    private static final long serialVersionUID = 1L;

    public PluginException(String string) {
        super(string);
    }
}
