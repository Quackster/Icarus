package org.alexdev.icarus.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Log {

	public static Logger getErrorLogger() {
		return LoggerFactory.getLogger("ErrorLogger");
	}
}
